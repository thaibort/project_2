<?php $__env->startSection('title','Phiếu thu'); ?>
<?php $__env->startSection('menu'); ?>
    <div class="order-last mr-10 hover:text-blue-700 font-bold h-14 flex items-center w-20 justify-center">
        <form action="<?php echo e(url('/')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" hidden name="mode" value="0" class="bg-opacity-0">
            <input type="submit" value="Trang chủ" class="bg-blue-200">
        </form>
    </div>
    <div class="order-last mr-10 border-red-500 border-b-2 hover:text-blue-700 font-bold h-14 flex items-center w-20 justify-center">
        <form action="<?php echo e(url('invoice')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" hidden name="mode" value="1" class="bg-opacity-0">
            <input type="submit" value="Phiếu thu" class="bg-blue-200">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="container mx-auto">
        <table class=" mr-10 table-auto w-full bg-gray-100 mt-10 text-center" cellpadding="0" cellspacing="0">
            <tr>
                <th class="h-14 bg-blue-700 border-2 border-black text-white">Mã sinh viên</th>
                <th class="h-14 bg-blue-700 border-2 border-black text-white">Ngành</th>
                <th class="h-14 bg-blue-700 border-2 border-black text-white">Khóa</th>
                <th class="h-14 bg-blue-700 border-2 border-black text-white">Lớp</th>
                <th class="h-14 bg-blue-700 border-2 border-black text-white">Họ và tên</th>
                <th class="h-14 bg-blue-700 border-2 border-black text-white">Tình trạng học phí</th>
                <th class="h-14 bg-blue-700 border-2 border-black text-white">Hành động</th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-300">
                    <td class="h-8 border-2 border-black text-center"><?php echo e($res -> id); ?></td>
                    <td class="h-8 border-2 border-black text-center"><?php echo e($res -> vocation); ?></td>
                    <td class="h-8 border-2 border-black text-center"><?php echo e($res -> schoolYear); ?></td>
                    <td class="h-8 border-2 border-black text-center"><?php echo e($res -> className); ?></td>
                    <td class="h-8 border-2 border-black text-center"><?php echo e($res -> name); ?></td>
                    <td class="h-8 border-2 border-black text-center">
                        <?php echo e($res -> stagesPresent <= $res -> totalStages
                            ? 'Đã nộp'
                            : 'Nợ '.($res -> stagesPresent - $res -> totalStages).' tháng'); ?>

                    </td>
                    <td class="h-8 border-2 border-black text-center">
                        <form action="<?php echo e(url("toinvoice")); ?>">
                            <input type="text" name="id" value="<?php echo e($res -> id); ?>" hidden>
                            <input type="text" name="mode" value="<?php echo e($mode); ?>" hidden>
                            <input type="submit" value="Tổng phiếu thu" class="bg-transparent">
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr class="h-8 border-2 border-black text-center">
                    <td colspan="8" class="">Không có dữ liệu sinh viên</td>
                </tr>
            <?php endif; ?>
        </table>
        <div class="w-full pl-20 absolute bottom-10 right-10">
            <?php echo e($rs->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/client/invoice.blade.php ENDPATH**/ ?>