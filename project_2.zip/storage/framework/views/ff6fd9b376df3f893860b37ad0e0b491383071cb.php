
<?php $__env->startSection('title','Quản lý lớp'); ?>
<?php $__env->startSection('content'); ?>
<div aria-colspan="3" class="pt-2">
    <a href="<?php echo e(url('admin/creclass')); ?>">
        <button aria-colspan="3" type="button" class="bg-blue text-white btn btn-primary">
            <i class="fas fa-plus-circle fa-lg "></i> Thêm lớp
        </button>
    </a>
</div>
<div class="pt-2">
    <table id="class" class="table table-bordered bg-white  text-center">
        <thead>
            <tr>
                <td>Lớp</td>
                <td>Ngành</td>
                <td>Khóa</td>
                <td style="width: 200px">Hành động</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($res -> name); ?></td>
                <td><?php echo e($res -> vocation); ?></td>
                <td><?php echo e($res -> schoolYear); ?></td>
                <td class="p-1">
                    <div class="d-flex flex-row col-12 ">
                        <div class="col-6 d-flex justify-content-end">
                            <form class="col-12 h-full" action='<?php echo e(url("admin/upclass/{$res->id}")); ?>'>
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="edit_hover col-12 bg-blue text-white btn btn-outline-secondary">Sửa</button>
                            </form>
                        </div>
                        <div class="flex-row w-full col-6 d-flex justify-content-end">
                            <form class="col-12 h-full " action='<?php echo e(url("admin/class/{$res->id}")); ?>'
                                method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <button type="button"
                                    class="btn btn-primary col-12 bg-red text-white btn btn-outline-secondary "
                                    data-toggle="modal" data-target="#a<?php echo e($res->id); ?>">
                                    Xóa
                                </button>
                                <div class="modal fade" id="a<?php echo e($res->id); ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Xác nhận</h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                Bạn có chắc muốn xóa
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Hủy</button>
                                                <button type="submit" class="btn btn-primary">Xác nhận</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function() {
    $('#class').DataTable();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/staff/class/class-mng.blade.php ENDPATH**/ ?>