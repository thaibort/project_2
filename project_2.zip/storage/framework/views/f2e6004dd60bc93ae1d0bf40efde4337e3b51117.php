
<?php $__env->startSection('title','Sửa lớp'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('admin/upclass')); ?>" method="post" class="m-2">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="pt-2">
        <a href="<?php echo e(url('admin/class')); ?>">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                class="bi bi-arrow-left-short text-black hover:text-green" viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                    d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z" />
            </svg>
            Quay lại

        </a>
    </div>
    <div class="pt-2">
        <label class="col-4 flex mr-xl-5"> Ngành:
            <select name="vocation" required class="form-control select2 select2-hidden-accessible" style="width: 100%;"
                data-select2-id="1" tabindex="-1">
                <?php $__currentLoopData = $vocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($voca -> idTotal); ?>" <?php if($res -> idTotalMoney == $voca -> idTotal): ?> selected <?php endif; ?>>
                    <?php echo e($voca -> name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <label class="col-4 flex mr-xl-5"> Khóa:
            <select name="schoolYear" required class=" form-control select2 select2-hidden-accessible"
                style="width: 100%;" data-select2-id="1" tabindex="-1">
                <?php $__currentLoopData = $SchoolYear; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year -> idYear); ?>" <?php if($res -> idSchoolYear == $year -> idYear): ?> selected <?php endif; ?>>
                    <?php echo e($year -> name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <label>
            <input type="text" name="id" value="<?php echo e($res -> id); ?>" hidden>
        </label>
        <label class="col-4 flex mr-xl-5">Tên lớp:
            <input type="text" name="name" value="<?php echo e($res -> name); ?>" required
                class=" form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                tabindex="-1">
        </label>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 d-flex justify-content-end ">
        <button type="submit" required
            class=" bg-blue text-white form-control select2 select2-hidden-accessible col-2 mt-5 mr-5 "
            data-select2-id="1" tabindex="-1">Sửa</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/staff/class/update-class.blade.php ENDPATH**/ ?>