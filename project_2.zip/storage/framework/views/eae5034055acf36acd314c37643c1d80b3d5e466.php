<?php $__env->startSection('title','Quản lý ngành'); ?>
<?php $__env->startSection('content'); ?>
   <div aria-colspan="3" class="pt-3">
        <a href="<?php echo e(url('admin/crevoca')); ?>">
        <button aria-colspan="3" type="button" class="bg-blue text-white btn btn-primary">
            <i class="fas fa-plus-circle fa-lg "></i> Thêm Niên Khóa
        </button>
    </a>
    </div>
    <div class="pt-2">
    <table id="vocation" class="table table-bordered bg-white text-center">
        <thead>
            <tr colspan="3">
            </tr>
            <tr class=" text-center" style="width: 200px">
                <th >
                    Tên ngành
                </th>
                <th >
                    Tổng tiền thu
                </th>
                <th colspan="2" >
                    Hành động
                </th>
            </tr>
            </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class=" text-center">
                    <?php echo e($res->name); ?>

                </td>
                <td class=" text-center">
                    <?php echo e(number_format($res->totalMoney)); ?>

                </td>
                <td class="">
                    <form class="w-full h-full  -p-5" action='<?php echo e(url("admin/upvoca/{$res->id}")); ?>'>
                        <?php echo csrf_field(); ?>
                        <button
                            type="submit"
                            class=" w-full h-full edit_hover border-0 bg-blue text-white btn bg-gradient-primary mrt-5"
                            style="width: 100%"
                        >Sửa</button>
                    </form>
                </td>
                <td class="">
                    <form class="w-full h-full bg-red-200" action='<?php echo e(url("admin/vocation")); ?>' method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" value="<?php echo e($res -> id); ?>" name="id" hidden>
                        <button
                            type="button" id="del" class="btn bg-gradient-danger"
                            style="width: 100%"
                            data-toggle="modal"
                            data-target="#a<?php echo e($res -> id); ?>"
                        >
                            Xóa
                        </button>

                        <div class="modal fade" id="a<?php echo e($res -> id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Xác nhận</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        Bạn có chắc muốn xóa
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                                        <button type="submit" class="btn btn-primary">Xác nhận</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4">Hiện không có dữ liệu</td>
            </tr>

            <?php endif; ?>
        </tbody>
    </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('.admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/vocation/vocation-mng.blade.php ENDPATH**/ ?>