
<?php $__env->startSection('title','Quản lý hóa đơn'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">
        <div class="pt-2">
            <a href='<?php echo e(url("admin/stageform/{$mode}")); ?>'>
                <button aria-colspan="3" type="button" class="bg-blue text-white btn btn-primary">
                    <i class="far fa-arrow-alt-circle-up"></i> Tăng đợt đóng tiền hiện tại
                </button>
            </a>
        </div>
        <div class="text-center">
            <h4>Đợt đóng tiền hiện tại của các khóa</h4>
                <div>(Từ: <?php echo e(date('d - m - Y',strtotime($time -> start))); ?>, đến: <?php echo e(date('d - m - Y',strtotime($time -> end))); ?>)</div>
            <div class="d-flex">
                <?php $__currentLoopData = $stage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2">
                        Khóa <?php echo e($res -> name); ?>: đợt <?php echo e($res -> stagesPresent); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<div class="pt-2">
    <table id="invoice" class="table table-bordered bg-white ">
        <thead>
            <tr class=" text-center">
                <th>Ngành</th>
                <th>Khóa</th>
                <th>Lớp</th>
                <th>Mã sinh viên</th>
                <th>Tên sinh viên</th>
                <th>Tình trạng</th>
                <th style="width: 250px">Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class=" text-center">
                <td><?php echo e($res -> vocation); ?></td>
                <td><?php echo e($res -> schoolYear); ?></td>
                <td><?php echo e($res -> className); ?></td>
                <td><?php echo e($res -> id); ?></td>
                <td><?php echo e($res -> name); ?></td>
                <td>
                    <?php echo e($res -> stagesPresent <= $res -> totalStages
                            ? 'Đã nộp'
                            : 'Nợ '.($res -> stagesPresent - $res -> totalStages).' tháng'); ?>

                </td>
                <td class=" pt-2">
                    <div class="d-flex flex-row w-full  ">
                        <div class="col-6">
                            <form action='<?php echo e(url("admin/toindetail")); ?>' class="d-flex justify-content-end">
                                <input type="text" value="<?php echo e($res -> id); ?>" name="id" hidden>
                                <input type="text" value="<?php echo e($mode); ?>" name="mode" hidden>
                                <button class=" bg-blue text-white btn btn-outline-secondary m-auto">
                                    Hóa đơn
                                </button>
                            </form>
                        </div>
                        <div class="col-6">
                            <form action='<?php echo e(url("admin/checkinfor")); ?>' class="d-flex justify-content-end">
                                <input type="text" value="<?php echo e($res -> id); ?>" name="id" hidden>
                                <input type="text" value="<?php echo e($mode); ?>" name="mode" hidden>
                                <button class=" bg-red text-white btn btn-outline-secondary m-auto">
                                    Thu phí
                                </button>
                            </form>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5">Không có dữ liệu</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function() {
    $('#invoice').DataTable();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/staff/invoice/invoice-mng.blade.php ENDPATH**/ ?>