<?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',$res->name); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('content'); ?>
<div class="pt-2">
    <a href='<?php echo e(url("admin/invoice/{$mode}")); ?>'>

        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
            class="bi bi-arrow-left-short text-black hover:text-green" viewBox="0 0 16 16">
            <path fill-rule="evenodd"
                d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z" />
        </svg>
        Quay lại

    </a>
</div>
<h2 class="text-center">
    <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    Danh sách hóa đơn sinh viên <?php echo e($res->name); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h2>
<table class="table table-bordered bg-white text-center">
    <tr>
        <th>ID</th>
        <th>Tên</th>
        <th>Loại thu</th>
        <th>Ngày thu</th>
        <th>Số tiền</th>
        <th style="width: 250px">Hành động</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($res -> id); ?></td>
        <td><?php echo e($res -> name); ?></td>
        <td><?php echo e($res -> typeOfTuition); ?></td>
        <td><?php echo e(date('d - m - Y',strtotime($res -> date))); ?></td>
        <td><?php echo e(number_format($res -> money)); ?></td>
        <td class=" pt-2">
            <div class="d-flex flex-row w-full  ">
                <div class="col-6">
                    <form action='<?php echo e(url("admin/detailinvoice")); ?>'>
                        <input type="text" name="id" value="<?php echo e($res -> id); ?>" hidden>
                        <input type="text" name="mode" value="<?php echo e($mode); ?>" hidden>
                        <button class=" bg-blue text-white form-control">Chi tiết</button>
                    </form>
                </div>
                <div class="col-6">
                    <form action="<?php echo e(url("admin/invoice")); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="text" name="mode" value="<?php echo e($mode); ?>" hidden>
                        <input hidden type="text" value="<?php echo e($res -> id); ?>" name="id">
                        <input hidden type="text" value="<?php echo e($res -> idStudent); ?>" name="idStudent">
                        <button class=" bg-red text-white form-control">Xóa</button>
                    </form>
                </div>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="6">Hiện chưa có hóa đơn</td>
    </tr>
    <?php endif; ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/staff/invoice/total-invoice-detail.blade.php ENDPATH**/ ?>