<?php $__env->startSection('title','Thêm sinh viên'); ?>

<?php $__env->startSection('content'); ?>
<div class="pt-2">
    <a href='<?php echo e(url("admin/stuinfor/{$id}")); ?>'>

        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
            class="bi bi-arrow-left-short text-black hover:text-green" viewBox="0 0 16 16">
            <path fill-rule="evenodd"
                d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z" />
        </svg>
        Quay lại

    </a>
</div>
<div class="pt-2">
    <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="<?php echo e(url('admin/upstudent')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="text" value="<?php echo e($res -> id); ?>" hidden name="id">

        <div>

            <label class="col-4" ss="col-4 flex mr-xl-5">
                Tên: <input type="text" name="name" value="<?php echo e($res -> name); ?>" required
                    class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                    tabindex="-1">
            </label>


            <label class="col-4">
                Số điện thoại: <input type="tel" name="phone" value="<?php echo e($res -> phone); ?>" required
                    class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                    tabindex="-1">
            </label>


            <label>
                Email: <input type="email" name="email" value="<?php echo e($res -> email); ?>" required
                    class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                    tabindex="-1">
            </label>


            <label class="col-4">
                Địa chỉ: <input type="text" name="address" value="<?php echo e($res -> address); ?>" required
                    class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                    tabindex="-1">
            </label>


            <label class="col-4">
                Ngày sinh: <input type="date" name="dob" value="<?php echo e($res -> dob); ?>" required
                    class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                    tabindex="-1">
            </label>


            <b> Giớ tính:&nbsp;</b>
            <label class="px-2">
                <input type="radio" value="1" name="gender" <?php if($res -> gender == 1): ?> checked <?php endif; ?>> Nam
            </label>
            <label>
                <input type="radio" value="0" name="gender" <?php if($res -> gender == 0): ?> checked <?php endif; ?>> Nữ
            </label>

        </div>
        <div class="pt-2">
            <label class="col-4 flex mr-xl-5">
                Chọn lớp:
                <select name="class" class="border-1  btn btn-outline-secondary mrt-5">
                    <?php $__empty_1 = true; $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resclass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($resclass -> id); ?>" <?php if($res -> idClass == $resclass -> id): ?> selected <?php endif; ?>>
                        <?php echo e($resclass -> name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option>Không có dữ liệu</option>
                    <?php endif; ?>
                </select>
            </label>
            <label class="col-4">
                Chọn loại học bổng:
                <select name="scholarship" class="border-1  btn btn-outline-secondary mrt-5">
                    <?php $__empty_1 = true; $__currentLoopData = $scholarship; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resscholarship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($resscholarship -> id); ?>" <?php if($res -> idScholarship == $resscholarship -> id): ?>
                        selected <?php endif; ?>>
                        <?php echo e($resscholarship -> id == 0 ? 'Không có học bổng' : $resscholarship -> type); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option>Không có dữ liệu</option>
                    <?php endif; ?>
                </select>
            </label>
        </div>
        <div class="col-12 d-flex justify-content-end ">
            <button type="submit" required
                class=" bg-blue text-white form-control select2 select2-hidden-accessible col-1 mt-5 mr-5 "
                data-select2-id="1" tabindex="-1">Lưu</button>
        </div>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/staff/student/update-student.blade.php ENDPATH**/ ?>