
<?php $__env->startSection('title','Quản lý học bổng'); ?>

<?php $__env->startSection('content'); ?>
<div aria-colspan="3" class="pt-2">
    <a href="<?php echo e(url('admin/crescholarship')); ?>">
        <button aria-colspan="3" type="button" class="bg-blue text-white btn btn-primary">
            <i class="fas fa-plus-circle fa-lg "></i> Thêm học bổng
        </button>
    </a>
</div>
<div class="pt-2">
    <table class="table table-bordered bg-white text-center">
        <thead>
            <tr>
                <td>Loại</td>
                <td>Số tiền</td>
                <td colspan="2">Hành động</td>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($res -> id !== 0): ?>
            <tr>
                <td><?php echo e($res -> type); ?></td>
                <td><?php echo e($res -> money); ?></td>
                <td>
                    <form class=" h-full bg-blue-200 " action='<?php echo e(url("admin/upscholarship/{$res->id}")); ?>'>
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                            class="w-full h-full edit_hover border-0 text-white  btn bg-gradient-primary mrt-5"
                            style="width: 100%">Sửa</button>
                    </form>
                </td>
                <td>
                    <form class=" h-full bg-red-200 " action='<?php echo e(url("admin/scholarship/{$res->id}")); ?>' method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <button type="button" class="btn btn-primary border-0 text-white  btn bg-red mrt-5"
                            style="width: 100%" data-toggle="modal" data-target="#a<?php echo e($res->id); ?>">
                            Xóa
                        </button>

                        <div class="modal fade" id="a<?php echo e($res->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Xác nhận</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        Bạn có chắc muốn xóa
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Hủy</button>
                                        <button type="submit" class="btn btn-primary">Xác nhận</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4"> Không có dữ liệu </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/scholarship/scholarship-mng.blade.php ENDPATH**/ ?>