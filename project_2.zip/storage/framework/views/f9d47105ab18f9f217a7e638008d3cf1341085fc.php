
<?php $__env->startSection('title','Quản lý niên khóa'); ?>
<?php $__env->startSection('content'); ?>
<div class="align-middle d-flex pt-3  justify-content-between">
    <a href="<?php echo e(url('admin/creschyear')); ?>">
        <button aria-colspan="3" type="button" class="bg-blue text-white btn btn-primary">
            <i class="fas fa-plus-circle fa-lg "></i> Thêm Niên Khóa
        </button>
    </a>
    <div class="pb-3">
        <form action="<?php echo e(url('admin/stageform')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="text" hidden name="mode" value="0">
            <button type="submit" class="bg-blue text-white btn btn-outline-secondary">
                <i class="fas fa-arrow-circle-down"></i> Giảm tổng đợt</button>
        </form>
    </div>
</div>
<table class="table table-bordered bg-white text-center">
    <thead>
        <tr>
            <th>Tên</th>
            <th>Đợt đóng tiền hiện tại</th>
            <th colspan="2">Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($res -> name); ?></td>
            <td><?php echo e($res -> stagesPresent); ?></td>
            <td>
                <form class="w-full h-full -p-5" action='<?php echo e(url("admin/upschyear/{$res->id}")); ?>'>
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="w-full h-full edit_hover border-0 text-white  btn bg-gradient-primary mrt-5"
                        style="width: 100%">Sửa</button>
                </form>
            </td>
            <td class="">
                <form class="w-full h-full -p-5" action='<?php echo e(url("admin/schyear/{$res->id}")); ?>' method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="button" class="btn btn-primary border-0 text-white  btn bg-red mrt-5"
                        style="width: 100%" data-toggle="modal" data-target="#a<?php echo e($res->id); ?>">
                        Xóa
                    </button>

                    <div class="modal fade text-black-50" id="a<?php echo e($res -> id); ?>" tabindex="-1"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Xác nhận</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    Bạn có chắc muốn xóa
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                                    <button type="submit" class="btn btn-primary">Xác nhận</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/school_year/school-year-mng.blade.php ENDPATH**/ ?>