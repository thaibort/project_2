
<?php $__env->startSection('title','Trang chủ'); ?>
<?php $__env->startSection('menu'); ?>
    <div class="order-last  border-red-500 border-b-2 mr-10 hover:text-blue-700 font-bold h-14 flex items-center w-20 justify-center">
        <form action="<?php echo e(url('/')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" hidden name="mode" value="0" class="bg-opacity-0">
            <input type="submit" value="Trang chủ" class="bg-blue-200">
        </form>
    </div>
    <div class="order-last mr-10 hover:text-blue-700 font-bold h-14 flex items-center w-20 justify-center">
        <form action="<?php echo e(url('invoice')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" hidden name="mode" value="1" class="bg-opacity-0">
            <input type="submit" value="Phiếu thu" class="bg-blue-200">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <h1>Home</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/client/home.blade.php ENDPATH**/ ?>