
<?php $__env->startSection('title', 'Quản lý sinh viên'); ?>
<?php $__env->startSection('content'); ?>
<div aria-colspan="3" class="pt-2">
    <a href="<?php echo e(url('admin/crestudent')); ?>">
        <button aria-colspan="3" type="button" class="bg-blue text-white btn btn-primary">
        <i class="fas fa-user-plus"></i> Thêm sinh viên
        </button>
    </a>
</div>
<div class="pt-2">
    <table id="student" class="table table-bordered bg-white text-center">
        <thead>
            <tr>
                <td>ID</td>
                <td>Tên</td>
                <td>Lớp</td>
                <td>Khóa</td>
                <td>Hành động</td>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($res -> id); ?></td>
                <td><?php echo e($res -> studentName); ?></td>
                <td><?php echo e($res -> className); ?></td>
                <td><?php echo e($res -> schoolYear); ?></td>
                <td><a href='<?php echo e(url("admin/stuinfor/{$res -> id}")); ?>'>Chi tiết</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">Không có dữ liệu</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function() {
    $('#student').DataTable();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/staff/student/student-mng.blade.php ENDPATH**/ ?>