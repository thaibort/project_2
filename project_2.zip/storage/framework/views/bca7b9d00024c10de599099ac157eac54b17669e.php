<?php $__env->startSection('title','Quản Học bổng'); ?>
<?php $__env->startSection('body'); ?>
    <div class="w-full h-screen bg-red-200">
        <a href="<?php echo e(url('admin/scholarship')); ?>">Quay lại</a>
        <div>
            create
        </div>
        <form action="<?php echo e(url('admin/upscholarship')); ?>" method="post" class="flex">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" name="id" value="<?php echo e($res->id); ?>" hidden>
                Học bổng loại <br>
                <input type="number" value="<?php echo e($res->type); ?>" name="name">
                Số tiền <br>
                <input type="number" value="<?php echo e($res->money); ?>" name="money">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit">Sửa</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('.admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/scholarship/update-scholarship.blade.php ENDPATH**/ ?>