<?php $__env->startSection('title','Quản lý học bổng'); ?>

<?php $__env->startSection('body'); ?>
    <div>
        <a href="<?php echo e(url('admin/crescholarship')); ?>">thêm niên khóa</a>
    </div>
    <table>
        <tr>
            <td>Loại</td>
            <td>Số tiền</td>
            <td colspan="2">Hành động</td>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($res -> type); ?></td>
                <td><?php echo e($res -> money); ?></td>
                <td></td>
                <td></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4"> Không có dữ liệu </td></tr>
        <?php endif; ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/scholarship/scholarship-mng.blade.php ENDPATH**/ ?>
