<?php $__env->startSection('title','Thu học phí'); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="pt-2">
    <form action='<?php echo e(url("admin/checkinfor")); ?>' class="d-flex justify-content-end">
        <input type="text" value="<?php echo e($res -> id); ?>" name="id" hidden>
        <input type="text" value="<?php echo e($mode); ?>" name="mode" hidden>
        <button class=" bg-red text-white btn btn-outline-secondary m-auto">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                 class="bi bi-arrow-left-short text-black hover:text-green" viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                      d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z" />
            </svg>
            Quay lại
        </button>
    </form>
    <a href='<?php echo e(url("admin/checkinfor/{$res -> id}")); ?>'>

    </a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__empty_1 = true; $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="pt-2">
    <div class="d-flex flex-row text-lg text-center">
        <table class="table table-bordered bg-white">
            <tr>
                <td> Tên: </td>
                <td><?php echo e($res -> studentName); ?></td>
            </tr>
            <tr>
                <td> Email: </td>
                <td><?php echo e($res -> email); ?></td>
            </tr>
            <tr>
                <td> Số điện thoại: </td>
                <td><?php echo e($res -> phone); ?></td>
            </tr>
            <tr>
                <td> Địa chỉ: </td>
                <td> <?php echo e($res -> address); ?></td>
            <tr>
                <td> Giới tính:</td>
                <td><?php echo e($res -> gender == 1 ? 'Nam' : 'Nữ'); ?></td>
            </tr>
            <tr>
                <td>Ngày sinh: </td>
                <td> <?php echo e($res -> dob); ?></td>
            </tr>

            <tr>
                <td> Lớp: </td>
                <td> <?php echo e($res -> className); ?></td>
            </tr>
            <tr>
                <td> Ngành học: </td>
                <td> <?php echo e($res -> vocation); ?></td>
            </tr>
            <tr>
                <td>Loại thu: </td>
                <td><?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($item -> name); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
            </tr>
            <tr>
                <td> Tổng tiền nộp: </td>
                <td> <?php echo e(number_format($total)); ?></td>
            </tr>
            <tr>
                <td> Ngày thu: </td>
                <td> <?php echo e(\Illuminate\Support\Carbon::now('Asia/Ho_Chi_Minh')->format('d-m-Y')); ?></td>
            </tr>
            <tr>
                <td> Người thu: </td>
                <td> <?php echo e(session()->get('admin.name')); ?></td>
            </tr>

        </table>
    </div>

    <form action='<?php echo e(url("admin/creinvoice")); ?>' method="post">
        <?php echo csrf_field(); ?>
        <input hidden type="text" value="<?php echo e(session()->get('admin.id')); ?>" name="admin">
        <input hidden type="text" value="<?php echo e($res -> id); ?>" name="id">
        <input hidden type="text" value="<?php echo e($mode); ?>" name="mode">
        <input hidden type="text" value="<?php echo e($total); ?>" name="money">
        <input hidden type="text" value='<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($item -> id); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>' name="type">
        <input hidden type="text" value="<?php echo e(\Illuminate\Support\Carbon::now('Asia/Ho_Chi_Minh')->toDateString()); ?>"
            name="date">
        <div class="col-12 d-flex justify-content-end ">
            <button type="submit" required
                class=" bg-blue text-white form-control select2 select2-hidden-accessible col-1 mt-4 mr-4 "
                data-select2-id="1" tabindex="-1">Xác nhận</button>
        </div>
    </form>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div colspan="6">Hiện chưa có hóa đơn</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/staff/invoice/create-invoice.blade.php ENDPATH**/ ?>