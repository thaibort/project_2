

<?php $__env->startSection('title','Thu học phí'); ?>

<?php $__env->startSection('content'); ?>
<div class="pt-2">
    <a href='<?php echo e(url("admin/invoice/{$mode}")); ?>'>

            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                class="bi bi-arrow-left-short text-black hover:text-green" viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                    d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z" />
            </svg>
            Quay lại

    </a>
</div>
<div class="pt-2">
    <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action='<?php echo e(url("admin/gocreinvoice")); ?>' method="post">
        <?php echo csrf_field(); ?>
        <div>
            <table class="table table-bordered bg-white ">
                <tr>
                    <td>Mã sinh viên</td>
                    <td><?php echo e($res -> id); ?></td>
                </tr>
                <tr>
                    <td>Tên sinh viên: </td>
                    <td><?php echo e($res -> studentName); ?></td>
                </tr>
                <tr>
                    <td>Mã sinh viên</td>
                    <td><?php echo e($res -> id); ?></td>
                </tr>
                <tr>
                    <td>Khóa:</td>
                    <td><?php echo e($res -> schoolYear); ?></td>
                </tr>
                <tr>
                    <td>Ngành:</td>
                    <td><?php echo e($res -> vocation); ?></td>
                </tr>
                <tr>
                    <td>Lớp:</td>
                    <td><?php echo e($res -> className); ?></td>
                </tr>
                <tr>
                    <td> Phương thức thu học phí:</td>
                    <td>
                        <select name="typeOfTuition" class="col-12 border-white"
                            style="outline: 2px solid transparent; outline-offset: 2px;">
                            <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item -> id); ?>">
                                <?php echo e($item -> name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                </tr>
            </table>
            <input type="text" name="id" hidden value="<?php echo e($res -> id); ?>">
            <input type="text" name="mode" hidden value="<?php echo e($mode); ?>">
        </div>
        <div class="col-12 d-flex justify-content-end ">
            <button type="submit"
                class=" bg-blue text-white form-control select2 select2-hidden-accessible col-1 mt-4 mr-4 "
                data-select2-id="1" tabindex="-1">Tiếp</button>
        </div>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/staff/invoice/check-information.blade.php ENDPATH**/ ?>