
<?php $__env->startSection('title','Quản lý niên khóa'); ?>
<?php $__env->startSection('content'); ?>
<div class="w-full h-screen bg-red-200 pt-2">
    <div class="pt-2">
        <a href="<?php echo e(url('admin/schyear')); ?>">

            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                class="bi bi-arrow-left-short text-black hover:text-green" viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                    d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z" />
            </svg>
            Quay lại

        </a>
    </div>
    <div class="pt-2">
        <form action="<?php echo e(url('admin/creschyear')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label class="col-4 flex mr-xl-4"> Niên khóa thứ:
                <input type="number" name="name" min="0" maxlength="9" required
                    class="m-1 form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                    tabindex="-1">
            </label>
            <div class="col-12 d-flex justify-content-end ">
                <button type="submit" required
                    class=" bg-blue text-white form-control select2 select2-hidden-accessible col-1 mt-5 mr-5 "
                    data-select2-id="1" tabindex="-1">Thêm</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('.admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/school_year/create-school-year.blade.php ENDPATH**/ ?>