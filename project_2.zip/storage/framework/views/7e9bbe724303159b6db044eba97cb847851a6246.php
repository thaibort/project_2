
<?php $__env->startSection('title','Sửa thông tin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-2" data-select2-id="34" >
    <a href="<?php echo e(url('admin/staffinfor')); ?>">

                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                    class="bi bi-arrow-left-short text-black hover:text-green" viewBox="0 0 16 16">
                    <path fill-rule="evenodd"
                        d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z" />
                </svg>
                Quay lại

    </a>
    <div  data-select2-id="33">
        <form action="<?php echo e(url('admin/poststaff')); ?>" method="post" class="m-2">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label class="m-3">
                        Họ và tên <br>
                        <input type="text" name="name" value="<?php echo e($res -> name); ?>" required class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1">
                    </label>
                    <label class="m-3">
                        Email <br>
                        <input type="text" name="email" value="<?php echo e($res -> email); ?>" required class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1">
                    </label>
                    <label class="m-3">
                        Số điện thoại  <br>
                        <input type="text" name="phone" value="<?php echo e($res -> phone); ?>" required class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1">
                    </label>
                    <label class="m-3">
                        Địa chỉ <br>
                        <input type="text" name="address" value="<?php echo e($res -> address); ?>" required class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1">
                    </label>
                </div>
                <div class="border-0" id="change">Đổi mật khẩu</div>
                <div id="pas">
                    <label class="m-3">
                        Mật khẩu cũ <br>
                        <input type="password" name="oldPass" class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1">
                    </label>
                    <label>
                        Mật khẩu mới <br>
                        <input type="password" name="newPass" class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1" tabindex="-1">
                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 d-flex justify-content-end">
            <button type="submit" class=" bg-blue text-white form-control select2 select2-hidden-accessible col-1 mt-5 mr-5 "  data-select2-id="1" tabindex="-1">Lưu</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $("#pas").toggle();
            $("#change").click(function(){
                $("#pas").toggle();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/staff/update-staff.blade.php ENDPATH**/ ?>