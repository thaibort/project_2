
<?php $__env->startSection('title','Quản lý ngành'); ?>
<?php $__env->startSection('content'); ?>
<div class="w-full h-screen bg-red-200 m-2">
    <div class="pt-2">
        <a href="<?php echo e(url('admin/schyear')); ?>">
            
        <i class="fas fa-undo"></i>
                Quay lại
            
        </a>
    </div>
    <div class="pt-2">
        <form action="<?php echo e(url('admin/upschyear')); ?>" method="post" class="flex">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" name="id" value="<?php echo e($item->id); ?>" hidden required
                class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                tabindex="-1">
            <label class="col-4 flex mr-xl-5"> Niên khóa: <br>
                <input type="number" value="<?php echo e($item->name); ?>" name="name" required
                    class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                    tabindex="-1">
            </label>
            <label class="col-4"> Đợt đóng tiền hiện tại: <br>
                <input type="number" value="<?php echo e($item->stagesPresent); ?>" name="stagesPresent" required
                    class="form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                    tabindex="-1">
            </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 d-flex justify-content-end ">
                   <button class=" bg-blue text-white form-control select2 select2-hidden-accessible col-1 mt-5 mr-5 "
                    data-select2-id="1" tabindex="-1">Sửa</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('.admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/school_year/update-school-year.blade.php ENDPATH**/ ?>