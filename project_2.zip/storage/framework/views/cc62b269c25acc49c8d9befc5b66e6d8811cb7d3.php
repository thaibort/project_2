
<?php $__env->startSection('title','Quản lý ngành'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-2" data-select2-id="34">
    <div class="pt-2">
        <a href="<?php echo e(url('admin/vocation')); ?>">

            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                class="bi bi-arrow-left-short text-black hover:text-green" viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                    d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z" />
            </svg>
            Quay lại

        </a>
    </div>
    <form action="<?php echo e(url('admin/crevoca')); ?>" method="post" class="col-12">
        <?php echo csrf_field(); ?>
        <label class="col-4 flex mr-xl-5">Tên Ngành:
            <input type="text" name="name" required class="m-1 form-control select2 select2-hidden-accessible"
                style="width: 100%;" data-select2-id="1" tabindex="-1">
        </label>
        <label class="col-4">Tổng Học Phí Ngành:
            <input type="text" name="money" min="0" maxlength="9" required
                class="m-3 form-control select2 select2-hidden-accessible" style="width: 100%;" data-select2-id="1"
                tabindex="-1">
        </label>
        <div class="col-12 d-flex justify-content-end ">
            <button type="submit"
                class=" bg-blue text-white form-control select2 select2-hidden-accessible col-1 mt-5 mr-5 "
                data-select2-id="1" tabindex="-1">Thêm</button>
        </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('.admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/vocation/create-vocation.blade.php ENDPATH**/ ?>