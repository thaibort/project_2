

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="pt-2">
    <table class="table table-bordered bg-white">
        <tr>
            <th>
                Tên
            </th>
            <td>
                <?php echo e($res -> name); ?>

            </td>
        </tr>
        <tr>
            <th>
                Email
            </th>
            <td>
                <?php echo e($res -> email); ?>

            </td>
        </tr>
        <tr>
            <th>
                Số điện thoại
            </th>
            <td>
                <?php echo e($res -> phone); ?>

            </td>
        </tr>
        <tr>
            <th>
                Địa chỉ
            </th>
            <td>
                <?php echo e($res -> address); ?>

            </td>
        </tr>
    </table>
</div>
<form action="<?php echo e(url('admin/upstaff')); ?>">
    <?php echo csrf_field(); ?>
    <div class="col-12 d-flex justify-content-end ">
        <button type="submit" required
            class=" bg-blue text-white form-control select2 select2-hidden-accessible col-2 mt-2 mr-2 "
            data-select2-id="1" tabindex="-1">Sửa thông tin</button>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_2\project_2\resources\views/admin/component/super/staff/staff-information.blade.php ENDPATH**/ ?>